#include "lcd.h"

void lcd_enable_pulse(void) {
	LCD_PORT |= (1 << LCD_EN);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_EN);
	_delay_us(100);
}

void lcd_send_nibble(uint8_t nibble) {
	if (nibble & (1 << 0)) LCD_PORT |= (1 << LCD_D4); else LCD_PORT &= ~(1 << LCD_D4);
	if (nibble & (1 << 1)) LCD_PORT |= (1 << LCD_D5); else LCD_PORT &= ~(1 << LCD_D5);
	if (nibble & (1 << 2)) LCD_PORT |= (1 << LCD_D6); else LCD_PORT &= ~(1 << LCD_D6);
	if (nibble & (1 << 3)) LCD_PORT |= (1 << LCD_D7); else LCD_PORT &= ~(1 << LCD_D7);
	lcd_enable_pulse();
}

void lcd_command(uint8_t cmd) {
	LCD_PORT &= ~(1 << LCD_RS);
	lcd_send_nibble(cmd >> 4);
	lcd_send_nibble(cmd);
	_delay_ms(2);
}

void lcd_data(uint8_t data) {
	LCD_PORT |= (1 << LCD_RS);
	lcd_send_nibble(data >> 4);
	lcd_send_nibble(data);
	_delay_ms(2);
}

void lcd_init(void) {
	LCD_DDR |= (1 << LCD_RS) | (1 << LCD_EN) | (1 << LCD_D4) | (1 << LCD_D5) | (1 << LCD_D6) | (1 << LCD_D7);
	_delay_ms(200);

	lcd_command(0x02); // Initialize in 4-bit mode
	lcd_command(0x28); // 2 lines, 5x8 matrix
	lcd_command(0x0C); // Display on, cursor off
	lcd_command(0x06); // Auto-increment cursor
	lcd_command(0x01); // Clear display
	_delay_ms(2);
}

void lcd_set_cursor(uint8_t row, uint8_t col) {
	uint8_t address = (row == 0) ? 0x80 + col : 0xC0 + col;
	lcd_command(address);
}

void lcd_write_string(char *str) {
	while (*str) {
		lcd_data(*str++);
	}
}

void lcd_clear(void) {
	lcd_command(0x01); // Clear display
	_delay_ms(20);
}
