#ifndef LCD_H_
#define LCD_H_

#include <avr/io.h>
#include <util/delay.h>

#define LCD_PORT PORTD
#define LCD_DDR  DDRD
#define LCD_RS   PD2
#define LCD_EN   PD3
#define LCD_D4   PD4
#define LCD_D5   PD5
#define LCD_D6   PD6
#define LCD_D7   PD7

void lcd_init(void);
void lcd_command(uint8_t cmd);
void lcd_data(uint8_t data);
void lcd_set_cursor(uint8_t row, uint8_t col);
void lcd_write_string(char *str);
void lcd_clear(void);

#endif /* LCD_H_ */
