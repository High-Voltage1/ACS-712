#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"

#define F_CPU 16000000UL
#define Tegangan_referensi 2.5 // Tegangan referensi pada arus nol
#define Sensitivitas_sensor 0.185 // Sensitivitas sensor (185mV/A untuk ACS712-05B)

void ADC_init() {
	ADMUX = (1 << REFS0); // tegangan referensi AVCC
	ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); // ADC enable, prescaler 128
}

uint16_t ADC_read(uint8_t ch) {
	ch &= 0b00000111; // memilih ADC channel ch antara 0-7
	ADMUX = (ADMUX & 0xF8) | ch; // clear the bottom 3 bits before ORing
	ADCSRA |= (1 << ADSC); // memulai konversi
	while (ADCSRA & (1 << ADSC)); // tunggu sampai konversi selesai
	return ADCW; // mengembalikan nilai ADC
}

float Perhitungan_arus(uint16_t adc_value) {
	float voltage = (adc_value / 1024.0) * 5.0;
	float current = (voltage - Tegangan_referensi) / Sensitivitas_sensor;
	return current;
}

int main(void) {
	lcd_init();
	lcd_clear();

	ADC_init();

	while (1) {
		uint16_t adc_value = ADC_read(0); // Baca dari ADC0 (PC0)
		float current = Perhitungan_arus(adc_value);

		char buffer[16];

		// Menampilkan nilai ADC di baris pertama
		lcd_set_cursor(0, 0);
		lcd_write_string("ADC Value: ");
		itoa(adc_value, buffer, 10); // konversi nilai ADC ke string
		lcd_write_string(buffer);

		// Menampilkan arus di baris kedua
		lcd_set_cursor(1, 0);
		lcd_write_string("Current: ");
		dtostrf(current, 5, 2, buffer); // konversi float ke string
		lcd_write_string(buffer);
		lcd_write_string(" A");

		_delay_ms(5000); // Delay 1 detik

		lcd_clear(); // Clear LCD before next update
	}

	return 0;
}
